%Instructions_function

instructions_menu = msgbox({'Instructions:';'In this game, it is your goal to /n launch projectiles at the enemy dealing damage, which will lower their life total. Once their life total reaches 0 you win! you wil be prompted with 2 inputs, angle, and power. There will also be a changing wind speed causing the ballistics of your projectile to vary.'})