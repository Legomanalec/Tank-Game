%landscape

function y = landscape(x)
    y = 2 + sin(0.5*pi*x) +sin(1.5*pi.*x); 
end
