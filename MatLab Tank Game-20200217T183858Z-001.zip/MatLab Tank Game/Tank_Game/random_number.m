%random_number

number_rand = randi(4)/10;

function number = random_number()
    number = number_rand;    
end
%WHY IS THIS NOT WORKING AS A GLOBAL RANDOM NUMBER